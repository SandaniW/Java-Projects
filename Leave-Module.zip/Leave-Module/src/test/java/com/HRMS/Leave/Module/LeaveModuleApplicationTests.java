package com.HRMS.Leave.Module;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeaveModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
