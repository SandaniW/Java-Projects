package com.HRMS.Leave.Module;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminLoginRepo extends JpaRepository<AdminLogin,Long> {
}
